from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username, password, host='localhost', port=33985, db='AAC', collection='animals'):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections.
        # This is hard-wired to use the aac database, the 
        # animals collection, and the aac user.
        # Definitions of the connection string variables are
        # unique to the individual Apporto environment.
        #
        # You must edit the connection variables below to reflect
        # your own instance of MongoDB!
        #
        # Connection Variables
        #
        """
        :param username: MongoDB username
        :param password: MongoDB password
        :param host: MongoDB host (default: localhost)
        :param port: MongoDB port (default: 33985)
        :param db: Database name (default: AAC)
        :param collection: Collection name (default: animals)
        """
        #
        # Initialize Connection
        #
        self.client = ("mongodb://localhost:27017/")
        self.database = self.client[db]
        self.collection = self.database[collection]
        
    # Complete this create method to implement the C in CRUD.
    def create(self, data):
        """
        Create a document in the MongoDB collection.
        :param data: A dictionary containing document data
        :return: True if successful, False otherwise
        """
        # Validate data input
        if data is not None and isinstance(data, dict):
            try:
                # Insert the document
                self.database.animals.insert_one(data)
                # Return True if successful
                return True
            except Exception as e:
                # Log the error
                print(f"Error inserting document: {e}")
                return False
        else:
            raise ValueError("Invalid data: Must be a non-empty dictionary.")

    # Create method to implement the R in CRUD.
    def read(self, query):
        """
        Read documents from the MongoDB collection based on a query.
        :param query: A dictionary representing the query filter
        :return: A list of matching documents, or an empty list if none found
        """
        # Validate query input
        if query is not None and isinstance(query, dict):
            try:
                # Use find() method
                results = list(self.database.animals.find(query))
                return results
            except Exception as e:
                # Log the error
                print(f"Error reading documents: {e}")
                return []
        else:
            raise ValueError("Invalid query: Must be a non-empty dictionary.")
            
    # Update method to implement the U in CRUD
    def update(self, query, update_data):
        """
        Update document(s) in the MongoDB collection based on a query.
        :param query: A dictionary representing the query filter
        :param update_data: A dictionary of key/value pairs for updating the document(s)
        :return: The number of documents updated
        """
        # Validate query and update_data inputs
        if query is not None and isinstance(query, dict) and update_data is not None and isinstance(update_data, dict):
            try:
                # Update matching documents
                result = self.database.animals.update_many(query, {"$set": update_data})
                # Return the number of documents updated
                return result.modified_count
            except Exception as e:
                # Log the error
                print(f"Error updating document(s): {e}")
                return 0
        else:
            raise ValueError("Invalid input: query and update_data must be non-empty dictionaries")
            
    # Delete method to implement the D in CRUD
    def delete(self, query):
        """
        Delete document(s) from the MongoDB collection based on a query.
        :param query: A dictionary representing the query filter
        :return: Number of documents deleted
        """
        # Validate the query input
        if query is not None and isinstance(query, dict):
            try:
                # Delete matching documents
                result = self.database.animals.delete_many(query)
                # Return number of documents deleted
                return result.deleted_count
            except Exception as e:
                # Log the error
                print(f"Error deleting document(s): {e}")
                return 0
        else:
            raise ValueError("Invalid query: Must be a non-empty dictionary.")
