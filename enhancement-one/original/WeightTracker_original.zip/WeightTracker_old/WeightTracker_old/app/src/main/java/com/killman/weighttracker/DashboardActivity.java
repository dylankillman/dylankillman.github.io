package com.killman.weighttracker;

import com.killman.weighttracker.data.AppDatabase;
import com.killman.weighttracker.data.DailyWeight;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.room.Room;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

public class DashboardActivity extends AppCompatActivity {

    private RecyclerView weightsRecyclerView;
    private DailyWeightAdapter dailyWeightAdapter;
    private AppDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        // Initialize standing button (SMS)
        Button smsSettingsButton = findViewById(R.id.smsSettingsButton);
        smsSettingsButton.setOnClickListener(v -> {
            // Open SmsActivity to allow user to enable/disable SMS notifications
            Intent intent = new Intent(DashboardActivity.this, SmsActivity.class);
            startActivity(intent);
        });

        // Initialize Floating Action Buttons (FABs)
        FloatingActionButton fabAddWeight = findViewById(R.id.fabAddWeight);
        FloatingActionButton fabSetGoal = findViewById(R.id.fabSetGoal);

        // Initialize RecyclerView
        weightsRecyclerView = findViewById(R.id.weightsRecyclerView);
        weightsRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Initialize the database
        db = Room.databaseBuilder(getApplicationContext(), AppDatabase.class, "weight_tracker_db").build();

        // Set up the FABs
        fabAddWeight.setOnClickListener(v -> {
            // Navigate to daily weight screen
            Intent intent = new Intent(DashboardActivity.this, AddWeightActivity.class);
            startActivity(intent);
        });

        fabSetGoal.setOnClickListener(v -> {
            // Navigate to where the goal weight can be set
            Intent intent = new Intent(DashboardActivity.this, GoalWeightActivity.class);
            startActivity(intent);
        });

        // Initialize the adapter and set it to RecyclerView
        dailyWeightAdapter = new DailyWeightAdapter(null);  // Start with an empty list
        weightsRecyclerView.setAdapter(dailyWeightAdapter);

        // Load daily weights to display with RecyclerView
        loadDailyWeights();
    }

    @Override
    protected void onResume() {
        super.onResume();

        // Check if the "refresh" flag is set
        if (getIntent().getBooleanExtra("refresh", false)) {
            // Refresh the data
            loadDailyWeights();
        }
    }

    // Method to load daily weights into RecyclerView
    private void loadDailyWeights() {
        new Thread(() -> {
            // Fetch daily weights from the database
            List<DailyWeight> dailyWeights = db.dailyWeightDao().getAll();
            runOnUiThread(() -> {
                // Update the adapter with the fetched data
                dailyWeightAdapter = new DailyWeightAdapter(dailyWeights);
                weightsRecyclerView.setAdapter(dailyWeightAdapter);
            });
        }).start();
    }
}