package com.killman.weighttracker.data;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface DailyWeightDao {

    // Insert a new daily weight record
    @Insert
    void insert(DailyWeight dailyWeight);

    // Fetch all daily weights (no user-specific filtering)
    @Query("SELECT * FROM daily_weight")
    List<DailyWeight> getAll(); // Fetch all daily weights

    // Fetch all daily weights for a specific user, ordered by date descending
    @Query("SELECT * FROM daily_weight WHERE userId = :userId ORDER BY date DESC")
    List<DailyWeight> getAllDailyWeights(int userId); // Fetch daily weights for a specific user

    // Delete a daily weight record
    @Delete
    void delete(DailyWeight dailyWeight);
}