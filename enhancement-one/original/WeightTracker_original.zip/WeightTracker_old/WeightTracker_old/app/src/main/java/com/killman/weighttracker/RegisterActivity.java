package com.killman.weighttracker;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import androidx.room.Room;

import com.killman.weighttracker.data.AppDatabase;
import com.killman.weighttracker.data.User;


public class RegisterActivity extends AppCompatActivity {
    private EditText usernameEditText, passwordEditText;
    private Button registerButton;
    private AppDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        // Initialize the views
        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        registerButton = findViewById(R.id.registerButton);

        // Initialize the database helper
        db = Room.databaseBuilder(getApplicationContext(),
                        AppDatabase.class, "weight_tracker_db")
                        .build();

        // Set onClickListener for the register button
        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = usernameEditText.getText().toString();
                String password = passwordEditText.getText().toString();

                // Make sure username and password are not empty
                if (!username.isEmpty() && !password.isEmpty()) {
                    // Add the user to the database
                    User user = new User();
                    user.username = username;
                    user.password = password;

                    // Insert the user using UserDao
                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            db.userDao().insert(user);

                            // Show confirmation message on UI
                            runOnUiThread(() -> {
                                Toast.makeText(RegisterActivity.this, "Registration Successful", Toast.LENGTH_SHORT).show();
                                finish(); // Close the registration screen and go back to login screen
                            });
                        }
                    }).start();
                } else {
                    // Show a message if any of the fields are empty
                    Toast.makeText(RegisterActivity.this, "Please fill in both fields", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
