package com.killman.weighttracker;

import android.content.SharedPreferences;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.widget.Button;
import android.content.Intent;
import android.widget.EditText;
import android.widget.Toast;

import androidx.room.Room;

import com.killman.weighttracker.data.AppDatabase;
import com.killman.weighttracker.data.User;

public class MainActivity extends AppCompatActivity {

    private EditText usernameEditText, passwordEditText;
    private Button loginButton, createAccountButton;
    private AppDatabase db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize views
        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        loginButton = findViewById(R.id.loginButton);
        createAccountButton = findViewById(R.id.createAccountButton);

        db = Room.databaseBuilder(getApplicationContext(),
                        AppDatabase.class, "weight_tracker_db")
                        .build();

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = usernameEditText.getText().toString();
                String password = passwordEditText.getText().toString();

                // Check credentials using DAO
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        // Get user by username and password
                        User user = db.userDao().getUserByUsernameAndPassword(username, password);
                        if (user != null && user.password.equals(password)) {
                            // Save user information in SharedPreferences
                            SharedPreferences sharedPreferences = getSharedPreferences("user_prefs", MODE_PRIVATE);
                            SharedPreferences.Editor editor = sharedPreferences.edit();
                            editor.putInt("user_id", user.id);  // Save user_id from the logged-in user
                            editor.putString("user_name", user.username);  // Save user_name from the logged-in user
                            editor.apply();  // Apply changes to SharedPreferences

                            // Navigate to DashboardActivity if credentials are valid
                            Intent intent = new Intent(MainActivity.this, DashboardActivity.class);
                            startActivity(intent);
                        } else {
                            // Show an error Toast if credentials are invalid
                            runOnUiThread(() -> Toast.makeText(MainActivity.this, "Invalid username or password", Toast.LENGTH_SHORT).show());
                        }
                    }
                }).start();
            }
        });

        // Set onClickListener for the Register button to take the user to RegisterActivity
        createAccountButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, RegisterActivity.class);
                startActivity(intent);
            }
        });
    }
}