package com.killman.weighttracker.data;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

@Dao
public interface GoalWeightDao {

    // Insert a new goal weight
    @Insert
    void insert(GoalWeight goalWeight);

    // Update an existing goal weight
    @Update
    void update(GoalWeight goalWeight);

    // Retrieve the goal weight for a user by userId
    @Query("SELECT * FROM goal_weight WHERE userId = :userId LIMIT 1")
    LiveData<GoalWeight> getGoalWeight(int userId);
}