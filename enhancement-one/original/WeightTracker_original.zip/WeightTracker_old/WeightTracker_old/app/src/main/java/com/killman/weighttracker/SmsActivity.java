package com.killman.weighttracker;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Switch;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class SmsActivity extends AppCompatActivity {

    private Switch smsSwitch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms); // Link to XML layout

        smsSwitch = findViewById(R.id.smsSwitch);

        // Retrieve saved state from SharedPreferences
        SharedPreferences sharedPreferences = getSharedPreferences("user_prefs", MODE_PRIVATE);
        boolean smsEnabled = sharedPreferences.getBoolean("sms_enabled", false);  // Default to false

        // Set the initial state of the switch
        smsSwitch.setChecked(smsEnabled);

        // Set listener to save the new state when toggled
        smsSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putBoolean("sms_enabled", isChecked);  // Save the state of the switch
            editor.apply();

            // Inform the user
            if (isChecked) {
                Toast.makeText(SmsActivity.this, "SMS notifications enabled.", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(SmsActivity.this, "SMS notifications disabled.", Toast.LENGTH_SHORT).show();
            }
        });
    }
}