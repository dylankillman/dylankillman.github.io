package com.killman.weighttracker;

import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;
import com.killman.weighttracker.data.AppDatabase;
import com.killman.weighttracker.data.DailyWeight;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.room.Room;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Locale;
import java.util.List;

public class DashboardActivity extends AppCompatActivity {

    private RecyclerView weightsRecyclerView;
    private DailyWeightAdapter dailyWeightAdapter;
    private AppDatabase db;

    private LineChart weightLineChart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        // Initialize standing button (SMS)
        Button smsSettingsButton = findViewById(R.id.smsSettingsButton);
        smsSettingsButton.setOnClickListener(v -> {
            // Open SmsActivity to allow user to enable/disable SMS notifications
            Intent intent = new Intent(DashboardActivity.this, SmsActivity.class);
            startActivity(intent);
        });

        // Initialize Floating Action Buttons (FABs)
        FloatingActionButton fabAddWeight = findViewById(R.id.fabAddWeight);
        FloatingActionButton fabSetGoal = findViewById(R.id.fabSetGoal);

        // Initialize RecyclerView
        weightsRecyclerView = findViewById(R.id.weightsRecyclerView);
        weightsRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Initialize LineChart
        weightLineChart = findViewById(R.id.weightLineChart);

        // Initialize the database
        db = Room.databaseBuilder(getApplicationContext(), AppDatabase.class, "weight_tracker_db").build();

        // Set up the FABs
        fabAddWeight.setOnClickListener(v -> {
            // Navigate to daily weight screen
            Intent intent = new Intent(DashboardActivity.this, AddWeightActivity.class);
            startActivity(intent);
        });

        fabSetGoal.setOnClickListener(v -> {
            // Navigate to where the goal weight can be set
            Intent intent = new Intent(DashboardActivity.this, GoalWeightActivity.class);
            startActivity(intent);
        });

        // Initialize the adapter and set it to RecyclerView
        dailyWeightAdapter = new DailyWeightAdapter(null);  // Start with an empty list
        weightsRecyclerView.setAdapter(dailyWeightAdapter);

        // Load daily weights to display with RecyclerView
        loadDailyWeights();
    }

    @Override
    protected void onResume() {
        super.onResume();

        // Check if the "refresh" flag is set
        if (getIntent().getBooleanExtra("refresh", false)) {
            // Refresh the data
            loadDailyWeights();
        }
    }

    // Method to load daily weights into RecyclerView
    private void loadDailyWeights() {
        new Thread(() -> {
            // Fetch daily weights from the database
            List<DailyWeight> dailyWeights = db.dailyWeightDao().getAll();
            runOnUiThread(() -> {
                // Update the adapter with the fetched data
                dailyWeightAdapter = new DailyWeightAdapter(dailyWeights);
                weightsRecyclerView.setAdapter(dailyWeightAdapter);
                displayWeightChart(dailyWeights);
            });
        }).start();
    }

    // Method to display the weight data in a line chart using MPAndroidChart.
    private void displayWeightChart(List<DailyWeight> dailyWeights) {
        // Return early if there's no data to plot
        if (dailyWeights == null || dailyWeights.isEmpty()) return;

        // Sort the entries by date to ensure the chart shows weight over time correctly
        Collections.sort(dailyWeights, Comparator.comparing(DailyWeight::getDate));

        ArrayList<Entry> entries = new ArrayList<>();  // Holds chart data points (x = index, y = weight)
        ArrayList<String> labels = new ArrayList<>();  // Stores date labels for potential X-axis use

        // Loop through the weight entries and convert each one into an Entry for the chart
        for (int i = 0; i < dailyWeights.size(); i++) {
            DailyWeight weight = dailyWeights.get(i);
            entries.add(new Entry(i, (float) weight.getWeight())); // X: index, Y: weight
            labels.add(weight.getDate()); // For labeling purposes (optional, depending on chart config)
        }

        // Create a dataset and apply visual styling
        LineDataSet dataSet = new LineDataSet(entries, "Weight Over Time");

        // Determine overall weight trend (compare first and last weights)
        float startingWeight = dailyWeights.get(0).getWeight();
        float endingWeight = dailyWeights.get(dailyWeights.size() - 1).getWeight();

        if (endingWeight < startingWeight) {
            // Weight went down
            dataSet.setColor(getResources().getColor(android.R.color.holo_green_dark));
            dataSet.setCircleColor(getResources().getColor(android.R.color.holo_green_dark));
        } else if (endingWeight > startingWeight) {
            // Weight went up
            dataSet.setColor(getResources().getColor(android.R.color.holo_red_dark));
            dataSet.setCircleColor(getResources().getColor(android.R.color.holo_red_dark));
        } else {
            // No change
            dataSet.setColor(getResources().getColor(android.R.color.darker_gray));
            dataSet.setCircleColor(getResources().getColor(android.R.color.darker_gray));
        }

        // Attach the dataset to the chart
        LineData lineData = new LineData(dataSet);
        weightLineChart.setData(lineData);

        // Configure X-Axis properties for better readability
        XAxis xAxis = weightLineChart.getXAxis();
        xAxis.setGranularity(1f);                          // Minimum interval between axis values
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);     // Show labels at the bottom
        xAxis.setValueFormatter(new IndexAxisValueFormatter(labels)); // Uses dates as the labels at the bottom
        xAxis.setDrawGridLines(false);                     // Remove vertical grid lines

        // Disable the right Y-axis for a cleaner look
        weightLineChart.getAxisRight().setEnabled(false);

        // Disable chart description text (optional UI tweak)
        weightLineChart.getDescription().setEnabled(false);

        // Disable chart legend (optional UI tweak)
        weightLineChart.getLegend().setEnabled(false);

        // Refresh the chart with new data
        weightLineChart.invalidate();
    }
}