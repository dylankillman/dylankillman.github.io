package com.killman.weighttracker;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.lifecycle.Observer;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.room.Room;

import java.util.List;

import android.telephony.SmsManager;

import com.killman.weighttracker.data.AppDatabase;
import com.killman.weighttracker.data.GoalWeight;
import com.killman.weighttracker.data.DailyWeight;
import com.killman.weighttracker.DailyWeightAdapter;

public class GoalWeightActivity extends AppCompatActivity {

    private EditText goalWeightEditText;
    private Button saveButton;
    private AppDatabase db;
    private GoalWeight existingGoalWeight; // Holds the current goal weight (if it exists)

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_goal_weight);

        // Initialize views
        goalWeightEditText = findViewById(R.id.goalWeightEditText);
        saveButton = findViewById(R.id.saveButton);

        // Initialize the database
        db = Room.databaseBuilder(getApplicationContext(), AppDatabase.class, "weight_tracker_db").build();

        // Observe the goal weight from the database
        observeGoalWeight();

        // Set up the save button to handle both add and update operations
        saveButton.setOnClickListener(v -> {
            String goalWeightInput = goalWeightEditText.getText().toString().trim();

            if (!goalWeightInput.isEmpty()) {
                // Convert goal weight to a float
                float goalWeight = Float.parseFloat(goalWeightInput);

                // Retrieve the user ID from SharedPreferences
                int userId = getUserIdFromPreferences();
                if (userId == -1) {
                    Toast.makeText(GoalWeightActivity.this, "User not logged in", Toast.LENGTH_SHORT).show();
                    return;
                }

                // If no existing goal weight found, create a new one, otherwise update it
                if (existingGoalWeight == null) {
                    // Create new goal weight
                    existingGoalWeight = new GoalWeight();
                    existingGoalWeight.setWeight(goalWeight);
                    existingGoalWeight.setUserId(userId);
                    saveGoalWeight(existingGoalWeight, true); // Inserting new goal weight
                } else {
                    // Update existing goal weight
                    existingGoalWeight.setWeight(goalWeight);
                    saveGoalWeight(existingGoalWeight, false); // Updating existing goal weight
                }
                // If the user has reached their goal weight, send an SMS notification
                if (existingGoalWeight != null && existingGoalWeight.getWeight() == goalWeight) {
                    SendGoalWeightReachedSMS sendSMS = new SendGoalWeightReachedSMS(GoalWeightActivity.this);
                    sendSMS.sendGoalWeightReachedSMS();
                }
            } else {
                Toast.makeText(GoalWeightActivity.this, "Please enter a goal weight", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Observe the goal weight from the database using LiveData
    private void observeGoalWeight() {
        int userId = getUserIdFromPreferences();
        db.goalWeightDao().getGoalWeight(userId).observe(this, new Observer<GoalWeight>() {
            @Override
            public void onChanged(GoalWeight goalWeight) {
                if (goalWeight != null) {
                    existingGoalWeight = goalWeight;
                    goalWeightEditText.setText(String.valueOf(goalWeight.getWeight()));  // Update the goal weight UI
                }
            }
        });
    }

    // Save goal weight to the database
    private void saveGoalWeight(GoalWeight goalWeight, boolean isNew) {
        new Thread(() -> {
            if (isNew) {
                db.goalWeightDao().insert(goalWeight);
                showToast("Goal weight added");
            } else {
                db.goalWeightDao().update(goalWeight);
                showToast("Goal weight updated");
            }
        }).start();
    }
    // Helper method to show toast on the main thread
    private void showToast(String message) {
        runOnUiThread(() -> Toast.makeText(GoalWeightActivity.this, message, Toast.LENGTH_SHORT).show());
    }

    // Helper method to retrieve the user ID from SharedPreferences
    private int getUserIdFromPreferences() {
        SharedPreferences sharedPreferences = getSharedPreferences("user_prefs", MODE_PRIVATE);
        return sharedPreferences.getInt("user_id", -1);
    }

    @Override
    protected void onResume() {
        super.onResume();
        observeGoalWeight();  // Re-observe the goal weight when the activity is resumed
    }
}