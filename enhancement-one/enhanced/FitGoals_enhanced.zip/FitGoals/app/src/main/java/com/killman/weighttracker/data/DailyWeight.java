package com.killman.weighttracker.data;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "daily_weight")
public class DailyWeight {
    @PrimaryKey(autoGenerate = true)
    public int id;
    public int userId;  // Foreign key to User
    public String date; // Date of the weight entry
    public float weight; // Weight value

    // Getter and Setter for weight
    public float getWeight() {
        return weight;
    }

    public void setWeight(float weight) {
        this.weight = weight;
    }

    // Getter and Setter for date
    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}