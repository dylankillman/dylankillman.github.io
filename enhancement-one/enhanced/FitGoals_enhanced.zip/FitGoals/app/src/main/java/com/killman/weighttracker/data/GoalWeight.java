package com.killman.weighttracker.data;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "goal_weight")
public class GoalWeight {

    @PrimaryKey(autoGenerate = true)
    public int id;

    public int userId;  // Foreign key to User
    public float weight; // Goal weight value

    // Getter and Setter methods
    public float getWeight() {
        return weight;
    }

    public void setWeight(float weight) {
        this.weight = weight;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }
}