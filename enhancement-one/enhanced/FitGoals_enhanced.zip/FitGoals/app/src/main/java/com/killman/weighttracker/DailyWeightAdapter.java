package com.killman.weighttracker;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.killman.weighttracker.data.DailyWeight;

import java.util.List;

public class DailyWeightAdapter extends RecyclerView.Adapter<DailyWeightAdapter.DailyWeightViewHolder> {

    private List<DailyWeight> dailyWeights;  // List to hold the daily weights

    // Constructor to initialize the list of daily weights
    public DailyWeightAdapter(List<DailyWeight> dailyWeights) {
        this.dailyWeights = dailyWeights;
    }

    // ViewHolder to hold each item of the list
    public static class DailyWeightViewHolder extends RecyclerView.ViewHolder {
        TextView dateTextView, weightTextView;

        public DailyWeightViewHolder(View itemView) {
            super(itemView);
            dateTextView = itemView.findViewById(R.id.dateTextView);  // Reference the date TextView
            weightTextView = itemView.findViewById(R.id.weightTextView);  // Reference the weight TextView
        }
    }

    @NonNull
    @Override
    public DailyWeightViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate the layout for each item
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_daily_weight, parent, false);
        return new DailyWeightViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull DailyWeightViewHolder holder, int position) {
        // Bind data to the views
        DailyWeight dailyWeight = dailyWeights.get(position);
        holder.dateTextView.setText(dailyWeight.getDate());  // Set the date
        holder.weightTextView.setText(String.valueOf(dailyWeight.getWeight()));  // Set the weight
    }

    @Override
    public int getItemCount() {
        return dailyWeights != null ? dailyWeights.size() : 0;
    }

    // Method to update the data in the adapter
    public void setDailyWeights(List<DailyWeight> dailyWeights) {
        this.dailyWeights = dailyWeights;
        notifyDataSetChanged();  // Refresh the RecyclerView
    }
}