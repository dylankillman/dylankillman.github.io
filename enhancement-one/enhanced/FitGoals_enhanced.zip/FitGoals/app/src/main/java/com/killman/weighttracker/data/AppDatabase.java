package com.killman.weighttracker.data;

import androidx.room.Database;
import androidx.room.RoomDatabase;

@Database(entities = {User.class, DailyWeight.class, GoalWeight.class}, version = 1)
public abstract class AppDatabase extends RoomDatabase {

    // Abstract methods to get DAOs
    public abstract UserDao userDao();
    public abstract DailyWeightDao dailyWeightDao();
    public abstract GoalWeightDao goalWeightDao();
}