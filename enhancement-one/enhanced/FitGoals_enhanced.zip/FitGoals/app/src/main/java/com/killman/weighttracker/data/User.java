package com.killman.weighttracker.data;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "user")
public class User {
    @PrimaryKey(autoGenerate = true) // Auto-generate the user ID
    public int id;
    public String username;
    public String password;
}
