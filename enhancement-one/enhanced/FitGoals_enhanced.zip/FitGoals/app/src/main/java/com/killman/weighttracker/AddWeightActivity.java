package com.killman.weighttracker;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import com.killman.weighttracker.data.AppDatabase;
import com.killman.weighttracker.data.DailyWeight;

import java.util.Calendar;
import java.util.Locale;

public class AddWeightActivity extends AppCompatActivity {

    private EditText weightEditText, dateEditText;
    private Button saveButton;
    private AppDatabase db;
    private String selectedDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_weight);

        // Initialize views
        weightEditText = findViewById(R.id.weightEditText);
        dateEditText = findViewById(R.id.dateEditText);
        saveButton = findViewById(R.id.saveButton);

        // Initialize the database
        db = Room.databaseBuilder(getApplicationContext(), AppDatabase.class, "weight_tracker_db").build();

        // Set up DatePicker for selecting the date
        dateEditText.setOnClickListener(v -> {
            Calendar calendar = Calendar.getInstance();
            DatePickerDialog datePickerDialog = new DatePickerDialog(
                    AddWeightActivity.this,
                    (view, year, monthOfYear, dayOfMonth) -> {
                        // Format the selected date
                        String date = String.format(Locale.US, "%02d/%02d/%04d", monthOfYear + 1, dayOfMonth, year);
                        dateEditText.setText(date);
                    },
                    calendar.get(Calendar.YEAR),
                    calendar.get(Calendar.MONTH),
                    calendar.get(Calendar.DAY_OF_MONTH)
            );
            datePickerDialog.show();
        });

        // Save weight and date
        saveButton.setOnClickListener(v -> {
            String weight = weightEditText.getText().toString();
            String date = dateEditText.getText().toString();

            if (!weight.isEmpty() && !date.isEmpty()) {
                // Save the daily weight entry
                DailyWeight dailyWeight = new DailyWeight();
                dailyWeight.weight = Float.parseFloat(weight);
                dailyWeight.date = date;

                new Thread(() -> {
                    db.dailyWeightDao().insert(dailyWeight);
                    runOnUiThread(() -> {
                        Toast.makeText(AddWeightActivity.this, "Weight saved!", Toast.LENGTH_SHORT).show();

                        // Notify DashboardActivity to reload the data
                        Intent intent = new Intent(AddWeightActivity.this, DashboardActivity.class);
                        intent.putExtra("refresh", true);
                        startActivity(intent);
                        finish(); // Close AddWeightActivity
                    });
                }).start();
            } else {
                Toast.makeText(AddWeightActivity.this, "Please fill in both fields", Toast.LENGTH_SHORT).show();
            }
        });
    }
}