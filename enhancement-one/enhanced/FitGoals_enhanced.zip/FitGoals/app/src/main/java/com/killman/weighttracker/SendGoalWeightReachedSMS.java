package com.killman.weighttracker;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import android.telephony.SmsManager;
import android.content.pm.PackageManager;
import android.Manifest;

public class SendGoalWeightReachedSMS extends AppCompatActivity {

    private Context context; // Context to access SharedPreferences

    // Constructor to pass context
    public SendGoalWeightReachedSMS(Context context) {
        this.context = context;
    }

    // Send SMS method
    public void sendGoalWeightReachedSMS() {
        // Check if SMS notifications are enabled in SharedPreferences
        SharedPreferences sharedPreferences = context.getSharedPreferences("user_prefs", Context.MODE_PRIVATE);
        boolean smsEnabled = sharedPreferences.getBoolean("sms_enabled", false);  // Default to false

        if (!smsEnabled) {
            // If SMS notifications are disabled, don't send the SMS and show a toast
            Toast.makeText(context, "SMS notifications are disabled. No alert sent.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Check if SMS permission is granted
        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            // If not, request permission
            ActivityCompat.requestPermissions((Activity) context, new String[]{Manifest.permission.SEND_SMS}, 1);
            return;
        }

        // Send the actual notification
        String message = "Congratulations! You have reached your goal weight!";
        String phoneNumber = "+15551234567"; // MUST BE CORRECT PHONE NUMBER (this is my specific emulator device)

        SmsManager smsManager = SmsManager.getDefault();
        smsManager.sendTextMessage(phoneNumber, null, message, null, null);
        Toast.makeText(context, "SMS Sent: " + message, Toast.LENGTH_SHORT).show();
    }
}