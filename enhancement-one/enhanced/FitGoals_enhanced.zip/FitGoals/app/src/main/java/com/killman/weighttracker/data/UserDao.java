package com.killman.weighttracker.data;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

@Dao
public interface UserDao {
    @Insert
    void insert(User user);

    @Query("SELECT * FROM user WHERE username = :username AND password = :password")
    User getUserByUsernameAndPassword(String username, String password);

    @Update
    void update(User user);
}