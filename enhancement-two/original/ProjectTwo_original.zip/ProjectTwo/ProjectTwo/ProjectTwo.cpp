/* 
Project Two
Dylan Killman
*/

#include <iostream>
#include <algorithm>
#include <fstream>
#include <sstream>
#include <vector>

using namespace std;

// Struct to represent a course with its number, title, and prerequisites.
struct Course {
    string courseNumber;
    string courseTitle;
    vector<string> prerequisites;
};
// Global vector to store all courses
vector<Course> courses;

// Function to load course data from a file into the vector of Course structures
void loadDataStructure(vector<Course>& courses, const string& fileName) {
    ifstream inputFile(fileName);
    if (inputFile.is_open()) {
        string line;
        // Read each line from the file and process it
        while (getline(inputFile, line)) {
            stringstream ss(line);
            Course course;
            string token;
            int tokenIndex = 0;
            while (getline(ss, token, ',')) {
                if (tokenIndex == 0) {
                    course.courseNumber = token;
                }
                else if (tokenIndex == 1) {
                    course.courseTitle = token;
                }
                else {
                    course.prerequisites.push_back(token);
                }
                tokenIndex++;
            }
            courses.push_back(course);
        }
        inputFile.close();
        cout << "Data loaded successfully.\n";
    }
    
    
    else {
        cout << "Error opening file. Please check the file name and try again.\n";
    }
}

// Function to print the list of courses in alphanumeric order based on course number
void printCourseList(const vector<Course>& courses) {
    vector<Course> sortedCourses = courses;
    sort(sortedCourses.begin(), sortedCourses.end(), [](const Course& a, const Course& b) {
        return a.courseNumber < b.courseNumber;
        });

    cout << "Here is a list of courses:" << endl;
    for (const auto& course : sortedCourses) {
        cout << course.courseNumber << ", " << course.courseTitle << endl;
    }
}

// Function to print detailed information about a specific course identified by courseNumber
void printCourseInfo(const string& courseNumber, const vector<Course>& courses) {
    bool found = false;
    // Search for the course in the list
    for (const auto& course : courses) {
        if (course.courseNumber == courseNumber) {
            found = true;
            cout << "Course Number: " << course.courseNumber << endl;
            cout << "Title: " << course.courseTitle << endl;
            // Print all prerequisites if there are any
            if (!course.prerequisites.empty()) {
                cout << "Prerequisites: ";
                for (auto it = course.prerequisites.begin(); it != course.prerequisites.end(); ++it) {
                    if (it != course.prerequisites.begin()) {
                        cout << ", ";
                    }
                    cout << *it;
                }
                cout << endl;
            }
            else {
                cout << "No prerequisites." << endl;
            }
            break;
        }
    }
    if (!found) {
        cout << "Course " << courseNumber << " not found." << endl;
    }
}

int main() {
    cout << "Welcome to the course planner\n";
    // Local vector to store course data
    vector<Course> courses;
    int choice = 0;
    string courseNumber;
    string fileName;

    while (true) {

        cout << "\nMenu:\n";
        cout << "1. Load Data Structure\n";
        cout << "2. Print Course List\n";
        cout << "3. Print Course Information\n";
        cout << "4. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        // Handles an invalid input
        if (cin.fail()) { 
            // Clears the error flags
            cin.clear();
            // Ignores the rest of the line
            cin.ignore(numeric_limits<streamsize>::max(), '\n'); 
            cout << "Invalid input. Please enter a number." << endl;
            // Skips the remaining code in this iteration
            continue; 
        }

        switch (choice) {
        case 1:
            cout << "Enter the file name: ";
            cin >> fileName;
            loadDataStructure(courses, fileName);
            break;
        case 2:
            printCourseList(courses);
            break;
        case 3:
            cout << "What course do you want to know about?: ";
            cin >> courseNumber;
            transform(courseNumber.begin(), courseNumber.end(), courseNumber.begin(), ::toupper);
            printCourseInfo(courseNumber, courses);
            break;
        case 4:
            cout << "Exiting the program.\n";
            return 0;
        default:
            cout << "Invalid choice. Please try again.\n";
        }
    }

    return 0;
}