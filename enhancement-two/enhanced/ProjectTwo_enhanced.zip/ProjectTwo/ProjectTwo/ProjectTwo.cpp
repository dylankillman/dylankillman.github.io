/* 
Project Two
Dylan Killman
*/

#include <iostream>
#include <algorithm>
#include <fstream>
#include <sstream>
#include <vector>
#include <chrono>

using namespace std;
using namespace std::chrono;

// Struct to represent a course with its number, title, and prerequisites.
struct Course {
    string courseNumber;            // Course ID (e.g. CSCI101)
    string courseTitle;             // Course title
    vector<string> prerequisites;   // List of any prerequisites required
};

// Node structure for BST
struct CourseNode {
    Course course;                  // Course data
    CourseNode* left;               // Pointer to left child node
    CourseNode* right;              // Pointer to right child node
    
    // Constructor to initialize node with a course
    CourseNode(Course c) : course(c), left(nullptr), right(nullptr) {}
};

// BST root
CourseNode* root = nullptr;

// Function to insert course into BST
CourseNode* insertCourse(CourseNode* node, const Course& course) {
    if (node == nullptr) {
        return new CourseNode(course); // Create a new node if null
    }
    if (course.courseNumber < node->course.courseNumber) {
        node->left = insertCourse(node->left, course); // Traverse left if smaller
    }
    else {
        node->right = insertCourse(node->right, course); // Traverse right if larger
    }
    return node;
}

// Function to load course data into BST
void loadDataStructure(const string& fileName) {
    ifstream inputFile(fileName);
    if (inputFile.is_open()) {
        string line;
        while (getline(inputFile, line)) {
            stringstream ss(line);
            Course course;
            string token;
            int tokenIndex = 0;

            // Split the CSV file line by commas
            while (getline(ss, token, ',')) {
                if (tokenIndex == 0) course.courseNumber = token;
                else if (tokenIndex == 1) course.courseTitle = token;
                else course.prerequisites.push_back(token);
                tokenIndex++;
            }
            root = insertCourse(root, course);
        }
        inputFile.close();
        cout << "Data loaded successfully.\n";
    }
    else {
        cout << "Error opening file.\n";
    }
}

// In-order traversal to print courses alphabetically
void inOrderTraversal(CourseNode* node) {
    if (node == nullptr) return;
    inOrderTraversal(node->left);
    cout << node->course.courseNumber << ", " << node->course.courseTitle << endl;
    inOrderTraversal(node->right);
}

// Search for a course in BST
CourseNode* searchCourse(CourseNode* node, const string& courseNumber) {
    if (node == nullptr || node->course.courseNumber == courseNumber) return node; // Go to left child
    if (courseNumber < node->course.courseNumber) return searchCourse(node->left, courseNumber);
    return searchCourse(node->right, courseNumber); // Go to right child
}

int main() {
    cout << "Welcome to the course planner\n";
    int choice = 0;
    string courseNumber;
    string fileName;

    while (true) {
        // Display menu
        cout << "\nMenu:\n";
        cout << "1. Load Data Structure\n";
        cout << "2. Print Course List\n";
        cout << "3. Print Course Information\n";
        cout << "4. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        // Invalid menu input
        if (cin.fail()) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Invalid input.\n";
            continue;
        }

        switch (choice) {
        case 1:
            // Load course data from CSV file into BST
            cout << "Enter the file name: ";
            cin >> fileName;
            {
                auto start = high_resolution_clock::now();
                loadDataStructure(fileName);
                auto end = high_resolution_clock::now();
                cout << "Loading data took " << duration_cast<microseconds>(end - start).count() << " microseconds.\n";
            }
            break;
        case 2:
            // Print all the courses in newly sorted order
        {
            auto start = high_resolution_clock::now();
            cout << "Here is a list of courses:" << endl;
            inOrderTraversal(root);
            auto end = high_resolution_clock::now();
            cout << "Printing course list took " << duration_cast<microseconds>(end - start).count() << " microseconds.\n";
        }
        break;
        case 3:
            // Look up a specific course and display details
            cout << "What course do you want to know about?: ";
            cin >> courseNumber;
            transform(courseNumber.begin(), courseNumber.end(), courseNumber.begin(), ::toupper); // Case match
            {
                auto start = high_resolution_clock::now();
                CourseNode* result = searchCourse(root, courseNumber);
                auto end = high_resolution_clock::now();
                if (result) {
                    cout << "Course Number: " << result->course.courseNumber << endl;
                    cout << "Title: " << result->course.courseTitle << endl;
                    if (!result->course.prerequisites.empty()) {
                        cout << "Prerequisites: ";
                        for (size_t i = 0; i < result->course.prerequisites.size(); ++i) {
                            cout << result->course.prerequisites[i];
                            if (i < result->course.prerequisites.size() - 1) cout << ", ";
                        }
                        cout << endl;
                    }
                    else {
                        cout << "No prerequisites." << endl;
                    }
                }
                else {
                    cout << "Course " << courseNumber << " not found." << endl;
                }
                cout << "Searching course info took " << duration_cast<microseconds>(end - start).count() << " microseconds.\n";
            }
            break;
        case 4:
            cout << "Exiting the program.\n";
            return 0;
        default:
            // Invalid input
            cout << "Invalid choice. Please try again.\n";
        }
    }

    return 0;
}